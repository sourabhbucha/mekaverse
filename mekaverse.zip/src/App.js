import './App.css';
import React from 'react';
import front from './Components/Assets/Img/1.png'
import logo from './Components/Assets/Img/logo.png'
import meka07 from './Components/Assets/Img/meka_07.jpg'
import { FaTwitter } from 'react-icons/fa';
import { SiDiscord } from 'react-icons/si';
import Slider from 'infinite-react-carousel';
function App() {
  return (
    <div className="App">
      <div className="front">
        <div className="front-flex">
          <img src={logo} alt="" />
          <h2>MekaVerse</h2>
          <div className="icons">
            <a href=""><FaTwitter /></a>
            <a href=""><SiDiscord /></a>
          </div>
        </div>
        <a href="">View on Opensea</a>
        <img src={front} alt="" />
      </div>
      <div className="section1">
        <div className="section1-grid">
        <div className="grid-section1">
          <h1>8,888 unique Mekas</h1>
          <h2>who need Drivers.</h2>
          <p>The MekaVerse is a collection of 8,888 generative Mekas with hundreds of elements inspired by the Japan Mecha universes.Each artwork is original, with its own color palette and creation. <br/> <br/>The objective was to make each Meka unique in order to prioritize quality above quantity.</p>
        </div>
        <img src={meka07} alt="" />
        </div>
      </div>
      <div className="section2">
        <Slider arrows={false} autoplay= {true} dots= {true} pauseOnHover={false} slidesPerRow={3}>
          <div className="center">
            <img src={meka07} alt="" />
          </div>
          <div className="center">
            <img src={meka07} alt="" />
          </div>
          <div className="center">
            <img src={meka07} alt="" />
          </div>
          <div className="center">
            <img src={meka07} alt="" />
          </div>
          <div className="center">
            <img src={meka07} alt="" />
          </div>
          <div className="center">
            <img src={meka07} alt="" />
          </div>
        </Slider>
      </div>
      <div className="section3">
        <h1>Roadmap</h1>
        <p>This roadmap outlines our goals and where we want to take MekaVerse. We have a lot of ideas and concepts that we are working on. It may evolve over time and hopefully become even better!</p>
        <div className="timeline">
          <h1><span>.01</span>Launch Roadmap</h1>
          <p>Quality comes first. The goal is to make our first drop as cool as possible so we can have freedom to develop the universe. We're still working on a number of rarity criteria, as well as a lot of new Lore concepts. The drop release date will be announced as soon as the project's quality and technical aspects are fully progressed. We also need to work hard with our community to make Discord and Twitter even cooler with new additions throughout time.</p>
        </div>
        <div className="timeline">
          <h1><span>.01</span>Launch Roadmap</h1>
          <p>Quality comes first. The goal is to make our first drop as cool as possible so we can have freedom to develop the universe. We're still working on a number of rarity criteria, as well as a lot of new Lore concepts. The drop release date will be announced as soon as the project's quality and technical aspects are fully progressed. We also need to work hard with our community to make Discord and Twitter even cooler with new additions throughout time.</p>
        </div>
        <div className="timeline">
          <h1><span>.01</span>Launch Roadmap</h1>
          <p>Quality comes first. The goal is to make our first drop as cool as possible so we can have freedom to develop the universe. We're still working on a number of rarity criteria, as well as a lot of new Lore concepts. The drop release date will be announced as soon as the project's quality and technical aspects are fully progressed. We also need to work hard with our community to make Discord and Twitter even cooler with new additions throughout time.</p>
        </div>
        <div className="timeline">
          <h1><span>.01</span>Launch Roadmap</h1>
          <p>Quality comes first. The goal is to make our first drop as cool as possible so we can have freedom to develop the universe. We're still working on a number of rarity criteria, as well as a lot of new Lore concepts. The drop release date will be announced as soon as the project's quality and technical aspects are fully progressed. We also need to work hard with our community to make Discord and Twitter even cooler with new additions throughout time.</p>
        </div>
        <div className="timeline">
          <h1><span>.01</span>Launch Roadmap</h1>
          <p>Quality comes first. The goal is to make our first drop as cool as possible so we can have freedom to develop the universe. We're still working on a number of rarity criteria, as well as a lot of new Lore concepts. The drop release date will be announced as soon as the project's quality and technical aspects are fully progressed. We also need to work hard with our community to make Discord and Twitter even cooler with new additions throughout time.</p>
        </div>
      </div>
      <div className="section4">
        <div className="section4-head">
          <h2>Who are we?</h2>
          <h1>Creative teams</h1>
        </div>
        <div className="section4-content">
          <p>Hi! Mattey & Matt. B are two friends currently focusing on 3D & Art direction. We have been working hard to establish our own style, and we're continuously looking for new ways to push ourselves. We also worked with Apple, Microsoft, MTV, Adobe, Adidas, Nike and more!</p>
        </div>
      </div>
      <div className="section5">
        <div className="section5-grid1 border-right">
          <div className="inline-flex">
            <h1>Mattey</h1>
            <div className="section5-icons">
              <a href=""><FaTwitter /></a>
              <a href=""><SiDiscord /></a>
            </div>
          </div>
          <img src={meka07} alt="" />
        </div>
        <div className="section5-grid2">
          <div className="inline-flex">
            <h1>NFTs Artworks</h1>
          </div>
          <Slider arrows={false} autoplay= {true} dots= {true} pauseOnHover={false} slidesPerRow={2}>
          <div className="seaction5-center">
            <img src={meka07} alt="" />
          </div>
          <div className="seaction5-center">
            <img src={meka07} alt="" />
          </div>
          <div className="seaction5-center">
            <img src={meka07} alt="" />
          </div>
          <div className="seaction5-center">
            <img src={meka07} alt="" />
          </div>
        </Slider>
        </div>
      </div>
      <div className="section5">
        <div className="section5-grid1 border-right">
          <div className="inline-flex">
            <h1>Mattey</h1>
            <div className="section5-icons">
              <a href=""><FaTwitter /></a>
              <a href=""><SiDiscord /></a>
            </div>
          </div>
          <img src={meka07} alt="" />
        </div>
        <div className="section5-grid2">
          <div className="inline-flex">
            <h1>NFTs Artworks</h1>
          </div>
          <Slider arrows={false} autoplay= {true} dots= {true} pauseOnHover={false} slidesPerRow={2}>
          <div className="seaction5-center">
            <img src={meka07} alt="" />
          </div>
          <div className="seaction5-center">
            <img src={meka07} alt="" />
          </div>
          <div className="seaction5-center">
            <img src={meka07} alt="" />
          </div>
          <div className="seaction5-center">
            <img src={meka07} alt="" />
          </div>
        </Slider>
        </div>
      </div>
      <div className="section7" style={{ backgroundImage: `url(${front})` }}>
        <div className="section7-content">
          <h1>Join the community</h1>
          <p>MekaVerse Discord already has over 200,000 members! If you want to join the #MEKAGANG it’s here. Join us to get the news as soon as possible and follow our latest announcements.</p>
          <a href="">Join our Discord</a>
        </div>
      </div>
      <div className="footer">
        <div className="footer-grid">
          <div className="footergrid1">
            <div className="flex">
              <img src={logo} alt="" />
              <h2>MekaVerse</h2>
            </div>
            <h3>8,888 unique mekas who need drivers.</h3>
            <p>©2021 MekaVerse. All rights reserved.</p>
          </div>
          <div className="footergrid2">
            <h1 className="blue">Home</h1>
            <h1>Team</h1>
            <h1>Terms & Conditions</h1>
            <div className="section7-icons">
              <a href=""><FaTwitter /></a>
              <a href=""><SiDiscord /></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default App;
